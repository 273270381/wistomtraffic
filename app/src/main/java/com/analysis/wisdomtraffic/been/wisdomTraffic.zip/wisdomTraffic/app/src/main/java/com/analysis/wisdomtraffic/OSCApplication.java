package com.analysis.wisdomtraffic;

/**
 * @Author hejunfeng
 * @Date 11:43 2021/3/11 0011
 * @Description com.analysis.wisdomtraffic
 **/
public class OSCApplication extends {
}
